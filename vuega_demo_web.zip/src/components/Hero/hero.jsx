import React from 'react'
import './hero.css'
import dark_arrow from "../../assets/images/dark_arrow.png"

const hero = () => {
  return (
    <div className='hero container'>
        <div className='hero-text'>
            <h1>Shaping Futures with Visionary Solutions</h1>
            <p>Vuega leads with unique solutions, reshaping the landscape of global business success,
                the charge in innovative solutions, transforming industries with unparalleled expertise</p>
            <button className='btn'>Explore Now <img src={dark_arrow} alt=''/></button>
        </div>
      
    </div>
  )
}

export default hero
