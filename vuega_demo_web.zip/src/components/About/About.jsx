import React from 'react'
import './About.css'
import about from "../../assets/images/about.png"
import play_icon from "../../assets/images/play_icon.png"


const About = () => {
  return (
    <div className='about'>
      <div className='about-left'>
        <img src={about}alt=''className='about-img'/>
        <img src={play_icon}alt=''className='play-icon'/>
      </div>
      <div className='about-right'>
        <h3>About us</h3>
        <h2>Transforming Visions into Reality</h2>
        <p>"Vuega stands at the forefront of technological innovation, specializing in web development, app development, and advanced machine learning (ML) and deep learning (DL) models. 
            Our mission is to craft cutting-edge solutions that empower businesses to thrive in the digital era.</p>
            <p>By leveraging our expertise and visionary technology,
              we drive success and create transformative digital experiences tailored to meet the unique needs of our clients."</p>
      </div>
    </div>
  )
}

export default About

//const About = ({setPlayState}) => {
//   return (
//     <div className='about'>
//       <div className='about-left'>
//         <img src={about}alt=''className='about-img'/>
//         <img src={play_icon}alt=''className='play-icon' onClick={()=>
//           {setPlayState()}
//         }/>