import React, { useState } from 'react'
import Navbar from './components/Navbar/navbar'
import Hero from './components/Hero/hero'
import Program from './components/programs/programs'
import Title from './components/Title/title'
import About from './components/About/About'
import Campus from './components/campus/campus'
import Testimonials from './components/Testimonials/testimonials'
import Contact from './components/contact/contact'
import Footer from './components/Footer/footer'


function App() {

  return (
    <div>
      <Navbar />
      <Hero />
      <div className="container">
        <Title subTitle='Our Domain' title='What we offer'/>
        <Program/>
        <About/>
        <Title subTitle ='Pictures'title='Our Environment'/>
        <Campus/>
        <Title subTitle ='Testimonials'title='What our client says'/>
        <Testimonials/>
        <Title subTitle ='Contact us'title='Get in Touch'/>
        <Contact/>
        <Footer/>
      </div>
    </div>
  )
}

export default App


// import Video from './components/Videoplayer/video'
  // // const [playState,setPlayState] = useState(false);
  //       {/* <Video playState={playState} setPlayState={setplayState}/> */}
  //         <About setPlayState={setPlayState}/>